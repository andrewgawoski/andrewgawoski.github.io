An early alpha build for Perdix, developed by Andrew Gawoski

At this stage in development, Perdix only supported gamepad input for gameplay and was specifically developed using Sony's Dualshock 4 controller. The title screen/main menu still supports mouse clicks but keyboard and mouse isn't a supported input method for gameplay.

The appropriate test level is accessed through "continue" and not "start," so I highly recommend using "continue" as the other option leads to a much older test level with very limited gameplay and functionality.

CONTROLS (Sony/Microsoft):
MENU:
	Left Stick: Move Selection
	Circle/B: Confirm

GAMEPLAY:
	Left Stick: Move Character & or wind direction
	Triangle/Y: Jump
	R1/RB: Slow Time & Control Wind


Some further explanations:
The character model is currently a white rectangle and is not an issue of asset loading. The test level features 3 unmarked checkpoints and no defining end of level features as you proceed right.

Wind has a direction shown by the compass in the bottom left and is controlled by holding down the "slow time & control wind" while moving the left stick to choose direction and magnitude and then releasing "slow time & control wind."

Wind affects the snow particle systems as well as player movement such as jumping.




